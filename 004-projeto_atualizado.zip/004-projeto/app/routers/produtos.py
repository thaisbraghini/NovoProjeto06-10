from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from .. import schemas, crud
from ..database import SessionLocal

router = APIRouter(prefix='/api/v1/produtos', tags=['produtos'])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post('', response_model=schemas.ProdutoOut, status_code=status.HTTP_201_CREATED)
def criar_produto(prod: schemas.ProdutoCreate, db: Session = Depends(get_db)):
    prod = crud.create_produto(db, prod.dict())
    return prod

@router.get('/{produto_id}', response_model=schemas.ProdutoOut)
def get_produto(produto_id: int, db: Session = Depends(get_db)):
    p = crud.get_produto(db, produto_id)
    if not p:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Produto não encontrado')
    return p

@router.get('/abaixo-minimo', response_model=list[schemas.ResumoEstoqueOut])
def abaixo_minimo(db: Session = Depends(get_db)):
    raw = crud.produtos_abaixo_minimo(db)
    return [schemas.ResumoEstoqueOut(**r) for r in raw]
