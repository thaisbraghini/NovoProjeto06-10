from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List
from .. import schemas, crud
from ..database import SessionLocal
from ..settings import settings

router = APIRouter(prefix='/api/v1/estoque', tags=['estoque'])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post('/movimentos', response_model=schemas.EstoqueMovimentoOut, status_code=status.HTTP_201_CREATED)
def criar_movimento(mov: schemas.EstoqueMovimentoCreate, db: Session = Depends(get_db)):
    return crud.criar_movimento(db, mov, allow_negative=settings.ALLOW_NEGATIVE_STOCK)

@router.get('/saldo/{produto_id}', response_model=schemas.SaldoOut)
def get_saldo(produto_id: int, db: Session = Depends(get_db)):
    produto = crud.get_produto(db, produto_id)
    if not produto:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Produto não encontrado')
    saldo = crud.calcular_saldo(db, produto_id)
    return {'produto_id': produto_id, 'saldo': saldo}

@router.post('/venda', response_model=schemas.EstoqueMovimentoOut, status_code=status.HTTP_201_CREATED)
def venda(produto_id: int = Query(...), quantidade: int = Query(..., gt=0), db: Session = Depends(get_db)):
    mov = schemas.EstoqueMovimentoCreate(produto_id=produto_id, tipo=schemas.MovimentoTipo.SAIDA, quantidade=quantidade, motivo='venda')
    return criar_movimento(mov, db)

@router.post('/devolucao', response_model=schemas.EstoqueMovimentoOut, status_code=status.HTTP_201_CREATED)
def devolucao(produto_id: int = Query(...), quantidade: int = Query(..., gt=0), db: Session = Depends(get_db)):
    mov = schemas.EstoqueMovimentoCreate(produto_id=produto_id, tipo=schemas.MovimentoTipo.ENTRADA, quantidade=quantidade, motivo='devolucao')
    return criar_movimento(mov, db)

@router.post('/ajuste', response_model=schemas.EstoqueMovimentoOut, status_code=status.HTTP_201_CREATED)
def ajuste(movimento: schemas.EstoqueMovimentoCreate, db: Session = Depends(get_db)):
    if not movimento.motivo:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail='Motivo é obrigatório para ajuste')
    return criar_movimento(movimento, db)

@router.get('/extrato/{produto_id}', response_model=List[schemas.EstoqueMovimentoOut])
def extrato(produto_id: int, limit: int = Query(50, ge=1, le=1000), offset: int = Query(0, ge=0), db: Session = Depends(get_db)):
    produto = crud.get_produto(db, produto_id)
    if not produto:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Produto não encontrado')
    movimentos = crud.listar_movimentos(db, produto_id, limit=limit, offset=offset)
    return movimentos

@router.get('/resumo', response_model=List[schemas.ResumoEstoqueOut])
def resumo(db: Session = Depends(get_db)):
    raw = crud.resumo_saldos(db)
    return [schemas.ResumoEstoqueOut(**r) for r in raw]
