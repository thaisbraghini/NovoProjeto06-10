from sqlalchemy.orm import Session
from sqlalchemy import func
from fastapi import HTTPException, status
from . import models, schemas

def get_produto(db: Session, produto_id: int):
    return db.query(models.Produto).filter(models.Produto.id == produto_id).first()

def create_produto(db: Session, produto_in: dict):
    prod = models.Produto(**produto_in)
    db.add(prod)
    db.commit()
    db.refresh(prod)
    return prod

def calcular_saldo(db: Session, produto_id: int) -> int:
    entradas = db.query(func.coalesce(func.sum(models.EstoqueMovimento.quantidade).filter(models.EstoqueMovimento.tipo == models.MovimentoTipo.ENTRADA), 0)).filter(models.EstoqueMovimento.produto_id == produto_id).scalar()
    saidas = db.query(func.coalesce(func.sum(models.EstoqueMovimento.quantidade).filter(models.EstoqueMovimento.tipo == models.MovimentoTipo.SAIDA), 0)).filter(models.EstoqueMovimento.produto_id == produto_id).scalar()
    entradas = entradas or 0
    saidas = saidas or 0
    return int(entradas) - int(saidas)

def criar_movimento(db: Session, movimento_in: schemas.EstoqueMovimentoCreate, allow_negative: bool):
    produto = get_produto(db, movimento_in.produto_id)
    if not produto:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Produto não encontrado')

    if movimento_in.quantidade <= 0:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail='Quantidade deve ser maior que zero')

    if movimento_in.tipo == schemas.MovimentoTipo.SAIDA:
        saldo_atual = calcular_saldo(db, movimento_in.produto_id)
        if not allow_negative and (saldo_atual - movimento_in.quantidade) < 0:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail='Saldo insuficiente para esta saída')

    movimento = models.EstoqueMovimento(
        produto_id=movimento_in.produto_id,
        tipo=models.MovimentoTipo(movimento_in.tipo.value),
        quantidade=movimento_in.quantidade,
        motivo=movimento_in.motivo
    )
    db.add(movimento)
    db.commit()
    db.refresh(movimento)
    return movimento

def listar_movimentos(db: Session, produto_id: int, limit: int = 50, offset: int = 0):
    q = db.query(models.EstoqueMovimento).filter(models.EstoqueMovimento.produto_id == produto_id).order_by(models.EstoqueMovimento.criado_em.desc()).offset(offset).limit(limit)
    return q.all()

def resumo_saldos(db: Session):
    produtos = db.query(models.Produto).all()
    res = []
    for p in produtos:
        saldo = calcular_saldo(db, p.id)
        res.append({
            'produto_id': p.id,
            'nome': p.nome,
            'saldo': saldo,
            'estoque_minimo': p.estoque_minimo,
            'abaixo_minimo': saldo < p.estoque_minimo
        })
    return res

def produtos_abaixo_minimo(db: Session):
    resumo = resumo_saldos(db)
    return [r for r in resumo if r['abaixo_minimo']]
