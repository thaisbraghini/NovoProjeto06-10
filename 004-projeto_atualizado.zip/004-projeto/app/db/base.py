from sqlalchemy.orm import declarative_base
# a classe Base do SQLAlchemy, da qual todos os modelos ORM (Object-Relational Mapping)
Base = declarative_base()